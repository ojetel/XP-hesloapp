﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestProject1
{
    public class Kalkulacka
    {
        public static int cislo1;
        public static int cislo2;

        public static int Soucet(int cislo1,int cislo2)
        {
            return cislo1 + cislo2;
        }
        public static double Podil(double cislo1, double cislo2)
        {
            return cislo1 / cislo2;
        }
    }
}
